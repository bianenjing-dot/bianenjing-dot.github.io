/* Progressive enhancement: all essential navigation is available as ordinary links. */

(() => {

  // A tiny mechanical switch sound, synthesized locally without media downloads.
  let clickAudio;
  let clickBuffer;
  let soundEnabled = true;
  try { soundEnabled = localStorage.getItem('portfolio-click-sound') !== 'off'; } catch {}
  let lastClickSound = -Infinity;
  function playRetroClick() {
    if (!soundEnabled || performance.now() - lastClickSound < 55) return;
    try {
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) return;
      clickAudio ||= new Audio();
      if (!clickBuffer) {
        const rate = clickAudio.sampleRate;
        clickBuffer = clickAudio.createBuffer(1, Math.ceil(rate * 0.065), rate);
        const data = clickBuffer.getChannelData(0);
        let seed = 1979, smooth = 0;
        for (let i = 0; i < data.length; i++) {
          const t = i / rate;
          seed = (1664525 * seed + 1013904223) >>> 0;
          const noise = seed / 2147483648 - 1;
          smooth += 0.42 * (noise - smooth);
          const attack = Math.min(1, t / 0.0008);
          const snap = smooth * Math.exp(-t * 230);
          const body = Math.sin(2 * Math.PI * 235 * t) * Math.exp(-t * 110);
          const release = t > 0.022 ? smooth * Math.exp(-(t - 0.022) * 280) * 0.22 : 0;
          data[i] = (snap * 0.7 + body * 0.22 + release) * attack;
        }
      }
      const startSound = () => {
        const source = clickAudio.createBufferSource();
        const volume = clickAudio.createGain();
        source.buffer = clickBuffer;
        volume.gain.value = 0.22;
        source.connect(volume).connect(clickAudio.destination);
        source.onended = () => { source.disconnect(); volume.disconnect(); };
        source.start();
      };
      lastClickSound = performance.now();
      if (clickAudio.state === 'suspended') clickAudio.resume().then(startSound).catch(() => {});
      else if (clickAudio.state === 'running') startSound();
    } catch { /* Navigation remains available when browser audio is unavailable. */ }
  }
  function soundTarget(event) {
    const target = event.target instanceof Element ? event.target : null;
    return target?.closest('a[href],button,summary,[role="button"],input[type="checkbox"],input[type="radio"]');
  }
  document.addEventListener('pointerdown', event => {
    const target = soundTarget(event);
    if (event.isTrusted && event.button === 0 && target && !target.matches(':disabled,[aria-disabled="true"],[data-sound-toggle]')) playRetroClick();
  }, {capture:true});
  // Keyboard activation does not have a pointerdown, so give it the same feedback.
  document.addEventListener('click', event => {
    const target = soundTarget(event);
    if (event.isTrusted && event.detail === 0 && target && !target.matches(':disabled,[aria-disabled="true"],[data-sound-toggle]')) playRetroClick();
  }, {capture:true});

  let cleanup;

  window.initPortfolio = function initPortfolio() {

    cleanup?.();

    // The standalone file keeps each image once in a shared embedded asset map.

    if (window.portfolioAssets) {

      document.querySelectorAll('img[data-inline-src]').forEach(img => {

        const data = window.portfolioAssets[img.dataset.inlineSrc];

        if (data) img.src = data;

      });

    }

    const controller = new AbortController();

    const signal = controller.signal;

    window.startAnimalMotion?.(document.querySelector(".neo-animal-banner"), signal);

    window.startCatMotion?.(document.querySelector("[data-cat-mascot]"), signal);

    window.styleRetroPlayer?.(document.querySelector(".millennium-player"), signal);



    const on = (el, type, callback) => el?.addEventListener(type, callback, { signal });

    const start = document.getElementById('start-toggle');

    const menu = document.getElementById('start-menu');

    document.querySelector('[data-sound-toggle]')?.remove();
    const soundToggle = document.createElement('button');
    soundToggle.type = 'button';
    soundToggle.dataset.soundToggle = '';
    soundToggle.className = menu ? 'retro-sound-menu' : 'retro-sound-floating';
    const updateSoundToggle = () => {
      soundToggle.textContent = soundEnabled ? 'Sound: on' : 'Sound: off';
      soundToggle.setAttribute('aria-label', soundEnabled ? 'Mute click sounds' : 'Enable click sounds');
      soundToggle.setAttribute('aria-pressed', String(soundEnabled));
    };
    updateSoundToggle();
    (menu || document.body).append(soundToggle);
    on(soundToggle, 'click', () => {
      soundEnabled = !soundEnabled;
      try { localStorage.setItem('portfolio-click-sound', soundEnabled ? 'on' : 'off'); } catch {}
      updateSoundToggle();
      if (soundEnabled) playRetroClick();
    });


    const dialog = document.getElementById('image-lightbox');

    const lightboxContent = document.getElementById('lightbox-content');

    let returnFocus = null;
    let activeAlbum = null;
    let soundtrack = null;

    let entering = false;

    let animations = [];

    let navigating = false;

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');

    const route=location.pathname === '/' && window.openPortfolioRoute ? location.hash.slice(1).split(/[?#]/)[0] || '/' : location.pathname;

    const scoped=document.querySelector('.neo-home')?'desktop':document.querySelector('.about-window')?'about':document.querySelector('.crt-splash')?'splash':null;

    if(scoped)document.body.dataset.motionPage=scoped;else delete document.body.dataset.motionPage;

    document.querySelectorAll('.icon-rail a,.task-current').forEach(a=>{

      const current=a.getAttribute('href')===route;

      if(current)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');

    });

    if(scoped){document.querySelector('main')?.classList.remove('motion-ready');requestAnimationFrame(()=>{if(!signal.aborted)document.querySelector('main')?.classList.add('motion-ready');});}

    if(scoped==='desktop')document.querySelectorAll('.neo-navigation>a').forEach(link=>{

      const tail=link.lastChild;

      if(tail?.nodeType===3&&tail.textContent.includes('↗')){

        tail.textContent=tail.textContent.replace('↗','');

        const arrow=document.createElement('span');arrow.className='motion-arrow';arrow.setAttribute('aria-hidden','true');arrow.textContent='↗';link.append(arrow);

      }

      on(link,'click',event=>{

        if(event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey||link.target)return;

        event.preventDefault();link.classList.add('is-pressed');

        const timer=setTimeout(()=>{if(window.openPortfolioRoute)window.openPortfolioRoute(link.getAttribute('href'));else location.assign(link.href);},reduced.matches?0:80);

        signal.addEventListener('abort',()=>clearTimeout(timer),{once:true});

      });

    });

    const closeMenu = (focus = false) => {

      if (!menu || menu.hidden) return;

      menu.hidden = true;

      start.setAttribute('aria-expanded', 'false');

      if (focus) start.focus();

    };

    on(start, 'click', () => {

      const open = menu.hidden;

      menu.hidden = !open;

      start.setAttribute('aria-expanded', String(open));

      if (open) menu.querySelector('a')?.focus();

    });

    on(document, 'click', event => {

      if (menu && !menu.hidden && !event.target.closest('.start-wrap')) closeMenu(menu.contains(document.activeElement));

      const musicTrigger=event.target.closest('[data-music]');
      if(musicTrigger&&dialog?.showModal){
        if(event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
        event.preventDefault();returnFocus=musicTrigger;activeAlbum=null;
        dialog.classList.add('soundtrack-viewer');
        dialog.setAttribute('aria-label','My little soundtrack player');
        dialog.querySelector('.lightbox-toolbar>span').textContent='My little soundtrack · Media Player';
        document.getElementById('lightbox-close').setAttribute('aria-label','Close music player');
        lightboxContent.innerHTML='<div class="soundtrack-cover"></div><audio class="soundtrack-media" controls preload="metadata" aria-label="My little soundtrack"></audio><p class="soundtrack-status" role="status">Ready to play</p>';
        soundtrack=lightboxContent.querySelector('audio');
        const cover=musicTrigger.querySelector('img').cloneNode(true);cover.loading='eager';lightboxContent.querySelector('.soundtrack-cover').append(cover);
        const src=musicTrigger.getAttribute('href');soundtrack.src=window.portfolioAssets?.[src]||src;
        const media=soundtrack;
        const state=text=>{if(soundtrack!==media||!dialog.open)return;lightboxContent.querySelector('.soundtrack-status').textContent=text;musicTrigger.classList.toggle('is-playing',text==='Playing');};
        soundtrack.addEventListener('playing',()=>state('Playing'));
        soundtrack.addEventListener('pause',()=>state(soundtrack.ended?'Finished':'Paused'));
        soundtrack.addEventListener('waiting',()=>state('Buffering…'));
        soundtrack.addEventListener('ended',()=>state('Finished'));
        soundtrack.addEventListener('error',()=>state('Unable to play this file. Please try opening the MP4 directly.'));
        dialog.showModal();document.getElementById('lightbox-close').focus();return;
      }
      const albumTrigger=event.target.closest('[data-album]');
      if(albumTrigger&&dialog?.showModal){
        if(event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
        const originals=[...document.getElementById(albumTrigger.dataset.album)?.querySelectorAll('img')||[]];
        if(!originals.length)return;
        event.preventDefault();returnFocus=albumTrigger;
        dialog.setAttribute('aria-label','Little moments — Photo Album');
        dialog.classList.add('memory-viewer');
        dialog.querySelector('.lightbox-toolbar>span').textContent='Little moments — Photo Album';
        document.getElementById('lightbox-close').setAttribute('aria-label','Close Photo Viewer');
        lightboxContent.innerHTML='<div class="memory-stage"></div><div class="memory-controls"><button type="button" class="button memory-prev" aria-label="Previous photo">← Previous</button><span class="memory-count" role="status" aria-live="polite" aria-atomic="true"></span><button type="button" class="button memory-next" aria-label="Next photo">Next →</button></div>';
        let index=0;
        const prev=lightboxContent.querySelector('.memory-prev'),next=lightboxContent.querySelector('.memory-next');
        const render=()=>{
          const img=originals[index].cloneNode(true);img.loading='eager';
          lightboxContent.querySelector('.memory-stage').replaceChildren(img);
          const fade=()=>{if(img.isConnected&&!reduced.matches)img.animate([{opacity:0},{opacity:1}],{duration:120,easing:'ease-out'});};
          if(img.complete)fade();else img.addEventListener('load',fade,{once:true});
          lightboxContent.querySelector('.memory-count').textContent=`${String(index+1).padStart(2,'0')} / ${String(originals.length).padStart(2,'0')}`;
        };
        activeAlbum=direction=>{index=(index+direction+originals.length)%originals.length;render();};
        prev.addEventListener('click',()=>activeAlbum?.(-1));next.addEventListener('click',()=>activeAlbum?.(1));
        render();albumTrigger.classList.add('camera-pressed');
        const timer=setTimeout(()=>{albumTrigger.classList.remove('camera-pressed');if(!signal.aborted&&!dialog.open){dialog.showModal();document.getElementById('lightbox-close').focus();}},reduced.matches?0:80);
        signal.addEventListener('abort',()=>{clearTimeout(timer);albumTrigger.classList.remove('camera-pressed');},{once:true});return;
      }

      const trigger = event.target.closest('[data-zoom]');

      if (trigger) {

        const target = document.getElementById(trigger.dataset.zoom);

        if (target && dialog?.showModal) {

          event.preventDefault();

          returnFocus = trigger;

          const art = target.cloneNode(true);

          art.removeAttribute('id');
          const portrait=trigger.dataset.zoom==='about-photo-preview';
          if(portrait)art.className='project-image-preview lightbox-image';
          dialog.setAttribute('aria-label',portrait?'Photo Viewer':'Project illustration preview');
          const viewerTitle=dialog.querySelector('.lightbox-toolbar>span');
          if(viewerTitle)viewerTitle.textContent=portrait?'Photo Viewer':'Project illustration';
          document.getElementById('lightbox-close')?.setAttribute('aria-label',portrait?'Close Photo Viewer':'Close illustration preview');

          if (art.classList.contains('project-image-preview')) art.classList.add('lightbox-image');

          const ids = new Map();

          art.querySelectorAll('[id]').forEach(el => {

            const oldId = el.id;

            el.id = `lightbox-${oldId}`;

            ids.set(oldId, el.id);

          });

          art.querySelectorAll('*').forEach(el => {

            for (const attr of [...el.attributes]) {

              let value = attr.value;

              ids.forEach((next, previous) => { value = value.replaceAll(`url(#${previous})`, `url(#${next})`); });

              if (value !== attr.value) el.setAttribute(attr.name, value);

            }

          });

          lightboxContent.replaceChildren(art);

          dialog.showModal();

          document.getElementById('lightbox-close')?.focus();

        }

      }

    });

    on(document, 'keydown', event => {

      if (event.key === 'Escape') closeMenu(true);
      if(dialog?.open&&activeAlbum&&(event.key==='ArrowLeft'||event.key==='ArrowRight')){event.preventDefault();activeAlbum(event.key==='ArrowLeft'?-1:1);}

    });

    on(document.getElementById('lightbox-close'), 'click', () => dialog.close());

    on(dialog, 'click', event => { if (event.target === dialog) dialog.close(); });

    on(dialog, 'close', () => { if(dialog.open)return; if(soundtrack){soundtrack.pause();soundtrack.removeAttribute('src');soundtrack.load();soundtrack=null;}document.querySelector('[data-music]')?.classList.remove('is-playing');activeAlbum=null;dialog.classList.remove('memory-viewer','soundtrack-viewer'); lightboxContent.replaceChildren(); returnFocus?.focus(); });

    const navigate = () => {

      if (navigating) return;

      navigating = true;

      try { sessionStorage.setItem('maikeliya-entered', '1'); } catch {}

      if (window.openPortfolioRoute) window.openPortfolioRoute('/desktop/');

      else location.assign('/desktop/');

    };

    const cancelAndEnter = () => {

      if (!entering) return;

      animations.forEach(a => a.cancel());

      navigate();

    };

    document.querySelectorAll('[data-enter]').forEach(link => on(link, 'click', async event => {

      if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;

      if (!Element.prototype.animate) return;

      event.preventDefault();

      if (entering) return;

      entering = true;

      let visited = false;

      try { visited = sessionStorage.getItem('maikeliya-entered') === '1'; } catch {}

      const replay = new URLSearchParams(location.search).has('replay') || window.previewReplay;

      if (reduced.matches || (visited && !replay)) { navigate(); return; }

      const screen = document.getElementById('screen-hotspot');

      if (!screen) { navigate(); return; }

      screen.classList.add('is-entering');

      const label=screen.querySelector('span');

      if(label){label.textContent='OPENING DESKTOP…';label.setAttribute('role','status');}

      try {

        animations=[screen.animate([{backgroundColor:'transparent'},{backgroundColor:'transparent',offset:.44},{backgroundColor:'rgba(0,0,0,.23)',offset:.45},{backgroundColor:'transparent'}],{duration:180,fill:'forwards'})];

        await Promise.all(animations.map(a=>a.finished));

      } catch {} finally { navigate(); }

    }));

    on(window, 'resize', cancelAndEnter);

    on(reduced, 'change', event => { if (event.matches) cancelAndEnter(); });

    initReadingMotion(signal, reduced);

    if (innerWidth < 640) document.querySelectorAll('.case-toc details').forEach(d => d.open = false);

    cleanup = () => {

      if(soundtrack){soundtrack.pause();soundtrack.removeAttribute('src');soundtrack.load();soundtrack=null;}
      controller.abort();

      animations.forEach(a => a.cancel());

      animations = [];

    };

  };

  window.initPortfolio();

  window.addEventListener('pageshow', event => { if (event.persisted) location.reload(); });

})();



// Delegation survives offline route navigation and editor iframe reloads.

document.addEventListener('click', event => {

 const button=event.target.closest('[data-run-toggle]');

 if(!button)return;

 const banner=button.closest('.neo-animal-banner');

 const paused=banner.dataset.running!=='paused';

 banner.dataset.running=paused?'paused':'running';

 button.setAttribute('aria-pressed',String(paused));

 button.setAttribute('aria-label',paused?'Play animal animation':'Pause animal animation');

 button.textContent=paused?'play':'pause';

});



/* Reading pages: native links and visible prose remain the baseline. */
function initReadingMotion(signal, reduced) {
  const root=document.querySelector('.work-window,.case-window,.contact-shell,.about-window');
  if(!root)return;
  document.body.dataset.motionPage=root.matches('.about-window')?'about':root.matches('.contact-shell')?'contact':root.matches('.case-window')?'case':'work';
  const on=(el,type,fn)=>el?.addEventListener(type,fn,{signal});
  const running=new Set(), pending=new Set();
  const animate=(el,frames,options)=>{
    if(!el?.animate||reduced.matches||signal.aborted)return;
    const a=el.animate(frames,options);running.add(a);
    a.finished.catch(()=>{}).finally(()=>running.delete(a));
  };
  const show=el=>{
    const waiting=pending.delete(el);el.classList.remove('reading-pending');
    if(waiting&&el.matches('h2'))animate(el.previousElementSibling,[{opacity:0,transform:'translateY(4px)'},{opacity:1,transform:'none'}],{duration:180,easing:'ease-out'});
    if(waiting)animate(el,[{opacity:0,transform:el.matches('blockquote,.project-figure,.millennium-player')?'none':'translateY(4px)'},{opacity:1,transform:'none'}],{duration:el.matches('h2')?180:220,easing:'ease-out'});
  };
  let observer;
  const revealAll=()=>{observer?.disconnect();pending.forEach(el=>el.classList.remove('reading-pending'));pending.clear();running.forEach(a=>a.cancel());};
  signal.addEventListener('abort',revealAll,{once:true});
  on(reduced,'change',event=>{if(event.matches)revealAll();});
  on(window,'beforeprint',revealAll);
  // Native find is not consistently observable: prose is never hidden. Also reveal
  // headings and artwork when a keyboard find command or beforematch is available.
  on(document,'keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='f')revealAll();});
  on(document,'beforematch',revealAll);
  on(document,'focusin',event=>{pending.forEach(el=>{if(el.contains(event.target))show(el);});});
  const revealTarget=target=>{
    if(!target)return;
    pending.forEach(el=>{if(target===el||target.contains(el)||el.contains(target)){pending.delete(el);el.classList.remove('reading-pending');}});
  };
  const hashTarget=()=>{
    let hash=location.hash.slice(1);
    // The standalone router stores its route and anchor in the same hash.
    if(hash.startsWith('/'))hash=hash.includes('#')?hash.slice(hash.indexOf('#')+1):'';
    try{return document.getElementById(decodeURIComponent(hash));}catch{return null;}
  };
  on(window,'hashchange',()=>revealTarget(hashTarget()));
  on(document,'click',event=>{
    const link=event.target.closest('a[href^="#"]');
    if(link)revealTarget(document.getElementById(link.getAttribute('href').slice(1)));
  });
  if(!reduced.matches&&'IntersectionObserver' in window&&Element.prototype.animate){
    try{
      const items=[...root.querySelectorAll('.case-section>h2,.gallery-header,.project-figure,.case-next,.work-projects>.project-card:not(:first-child),.about-player-column>h2,.education-summary>h2,.about-section>.eyebrow,.experience-row h3,.skills-grid h3,.millennium-player')];
      observer=new IntersectionObserver(entries=>entries.forEach(entry=>{
        if(entry.isIntersecting||entry.boundingClientRect.bottom<0){show(entry.target);observer.unobserve(entry.target);}
      }),{rootMargin:'0px 0px -15% 0px',threshold:0});
      // Register first; only then enable a pending state, and never hide the first screen.
      items.forEach(el=>{observer.observe(el);if(el.getBoundingClientRect().top>innerHeight){pending.add(el);el.classList.add('reading-pending');}});
      revealTarget(hashTarget());
      root.querySelectorAll('blockquote').forEach(el=>{
        const quoteObserver=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){animate(el,[{opacity:.35},{opacity:1}],{duration:220,easing:'ease-out'});quoteObserver.disconnect();}},{rootMargin:'0px 0px -15% 0px'});
        quoteObserver.observe(el);signal.addEventListener('abort',()=>quoteObserver.disconnect(),{once:true});
      });
    }catch{revealAll();}
  }
  const intro=root.querySelector('.collection-header,.case-header,.about-hero>div');
  if(intro)animate(intro,[{opacity:0,transform:'translateY(4px)'},{opacity:1,transform:'none'}],{duration:200,easing:'ease-out'});
  // Cards keep their existing image, title and text links; no nested anchor or
  // click-only wrapper is introduced. Press feedback precedes ordinary navigation.
  root.querySelectorAll('.project-card a').forEach(link=>on(link,'click',event=>{
    if(event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey||link.target||reduced.matches)return;
    event.preventDefault();const card=link.closest('.project-card');card.classList.add('project-pressed');
    const timer=setTimeout(()=>{if(window.openPortfolioRoute)window.openPortfolioRoute(link.getAttribute('href'));else location.assign(link.href);},80);
    signal.addEventListener('abort',()=>clearTimeout(timer),{once:true});
  }));
  const toc=root.querySelector('.case-toc');
  if(toc){
    const details=toc.querySelector('details'), summary=toc.querySelector('summary');
    const links=[...toc.querySelectorAll('a[href^="#"]')];
    const sections=links.map(link=>({link,section:document.getElementById(link.hash.slice(1))})).filter(x=>x.section).sort((a,b)=>a.section.compareDocumentPosition(b.section)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1);
    let frame=0;
    const update=()=>{
      frame=0;const line=Math.min(innerHeight*.28,180);
      let current=sections.filter(x=>x.section.getBoundingClientRect().top<=line).at(-1);
      if(innerHeight+scrollY>=document.documentElement.scrollHeight-4)current=sections.at(-1);
      sections.forEach(({link})=>{if(link===current?.link)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});
    };
    on(window,'scroll',()=>{if(!frame)frame=requestAnimationFrame(update);});
    on(window,'resize',update);update();
    const mobile=matchMedia('(max-width:639px)');
    details.open=!mobile.matches;
    on(mobile,'change',()=>{details.open=!mobile.matches;});
    links.forEach(link=>on(link,'click',()=>{
      const target=document.getElementById(link.hash.slice(1));revealTarget(target);
      if(mobile.matches){details.open=false;target?.setAttribute('tabindex','-1');target?.focus({preventScroll:true});}
    }));
    on(document,'keydown',event=>{if(event.key==='Escape'&&details.open&&mobile.matches){details.open=false;summary.focus();}});
    on(document,'click',event=>{if(mobile.matches&&details.open&&!toc.contains(event.target)){const focused=toc.contains(document.activeElement);details.open=false;if(focused)summary.focus();}});
    signal.addEventListener('abort',()=>cancelAnimationFrame(frame),{once:true});
  }
  if(root.matches('.contact-shell')){
    const content=root.querySelector('.contact-content');
    [...content.children].forEach(el=>{
      const delay=el.matches('.big-envelope')?0:el.matches('a,.contact-location')?80:40;
      animate(el,[{opacity:0},{opacity:1}],{duration:160,delay,fill:'backwards',easing:'ease-out'});
    });
  }
}
